cat > /etc/systemd/system/prometheus.service << EOF
[Unit]
Description=prometheus
Documentation=https://prometheus.io/
After=network.target
[Service]
Type=simple
ExecStart=$PWD/prometheus --web.listen-address="0.0.0.0:9090" --storage.tsdb.retention.time=30d --config.file=$PWD/prometheus.yml --storage.tsdb.path="$PWD/data/"
Restart=on-failure
[Install]
WantedBy=multi-user.target
EOF




systemctl daemon-reload

systemctl start prometheus.service 
systemctl enable prometheus.service
systemctl status prometheus.service
